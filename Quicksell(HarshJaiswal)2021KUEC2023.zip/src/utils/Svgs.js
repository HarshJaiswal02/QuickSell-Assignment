import Add from "../assets/icons_FEtask/add.svg";
import ThreeDotMenu from "../assets/icons_FEtask/3 dot menu.svg";
import Backlog from "../assets/icons_FEtask/Backlog.svg";
import Cancelled from "../assets/icons_FEtask/Cancelled.svg";
import Todo from "../assets/icons_FEtask/To-do.svg";
import Done from "../assets/icons_FEtask/Done.svg";
import InProgress from "../assets/icons_FEtask/in-progress.svg";
import HighPriority from "../assets/icons_FEtask/Img - High Priority.svg";
import LowPriority from "../assets/icons_FEtask/Img - Low Priority.svg";
import MediumPriority from "../assets/icons_FEtask/Img - Medium Priority.svg";
import NoPriority from "../assets/icons_FEtask/No-priority.svg";
import UrgentPriorityColor from "../assets/icons_FEtask/SVG - Urgent Priority colour.svg";
import UrgentPriority from "../assets/icons_FEtask/SVG - Urgent Priority grey.svg";
import Dot from "../assets/icons_FEtask/dot.svg";
export {
  Add,
  ThreeDotMenu,
  Backlog,
  Cancelled,
  Todo,
  Done,
  InProgress,
  HighPriority,
  LowPriority,
  MediumPriority,
  NoPriority,
  UrgentPriorityColor,
  UrgentPriority,
  Dot,
};
